class Carrito {
    #units
    #catalog
    #formatPrice

    constructor({catalog, formatPrice}) {
        this.#units = {}
        this.#catalog = catalog
        this.#formatPrice = formatPrice
    }

    setUnits({sku, units}) {
        if (units > 0) {
            this.#units[sku] = units
            console.log('units actualizadas', this.#units)
            return units
        } else {
            delete this.#units[sku]
            console.log('units actualizadas', this.#units)
            return 0
        }
    }

    total() {
        const products = []
        let total = 0
        this.#catalog.products.forEach(product => {
            if (typeof this.#units[product.SKU] !== 'undefined') {
                const subtotal = product.price * this.#units[product.SKU]
                products.push({
                    sku: product.SKU,
                    subtotal: this.#formatPrice({price: subtotal, currency: this.#catalog.currency}),
                    title: product.title
                })
                total += subtotal
            }
        })
        return {products, total: this.#formatPrice({price: total, currency: this.#catalog.currency}), currency: this.#catalog.currency}
    }
}
