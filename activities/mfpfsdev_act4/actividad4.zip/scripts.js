let carrito

const JSON_BLOB_ID = '1338935834543579136'

const formatPrice = ({price, currency}) => `${Number.parseFloat(price).toFixed(2)}${currency}`

const sync = () => {
    const total = carrito.total()

    const wrapper = document.querySelector('#carrito')
    wrapper.querySelectorAll('#carrito-products [data-sku]').forEach(row => {
        const sku = row.dataset.sku
        const totalProduct = total.products.find(product=>product.sku === sku)
        const subtotal = (typeof totalProduct !== 'undefined') ? totalProduct.subtotal : formatPrice({price: 0, currency: total.currency})
        row.querySelector('.template-total').textContent = subtotal
    })

    const wrapperProductTicketList = wrapper.querySelector('#carrito-total-products')
    const templateProductTicketRow = wrapper.querySelector('#carrito-total-row-template')

    wrapperProductTicketList.textContent = ''
    total.products.forEach(product => {
        const row = templateProductTicketRow.content.cloneNode(true)
        row.querySelector('.template-title').textContent = product.title
        row.querySelector('.template-subtotal').textContent = product.subtotal
        wrapperProductTicketList.append(row)
    })

    wrapper.querySelector('#carrito-total').textContent = total.total
}

const productActionClickHandler = (event) => {
    const action = event.target.dataset.action
    const row = event.target.closest('[data-sku]')
    const sku = row.dataset.sku
    switch(action) {
        case 'plus':
        case 'minus': {
            const unitsInput = row.querySelector('.carrito-units')
            let units = Number(unitsInput.value)
            units += (action === 'plus') ? 1 : -1
            unitsInput.value = carrito.setUnits({units, sku})
            break
        }
        case 'set' : {
            const units = Number(event.target.value)
            carrito.setUnits({units, sku})
            break
        }
        default: {
            throw new Error('accion no reconocida')
        }
    }
    sync()
}

const initPaintProducts = ({currency, products}) => {
    const wrapper = document.querySelector('#carrito')
    const productsWrapper = wrapper.querySelector('#carrito-products')
    const template = wrapper.querySelector('#carrito-product-template')
    const actionEventDictionary = {
        'INPUT' : 'change',
        'BUTTON': 'click'
    }
    products.forEach(product => {
        const row = template.content.cloneNode(true)
        row.querySelector('.template-title').textContent = product.title
        row.querySelector('.template-sku').textContent = product.SKU
        row.querySelector('.template-row').dataset.sku = product.SKU
        row.querySelector('.template-price').textContent = formatPrice({currency, price: product.price})
        row.querySelector('.template-total').textContent = formatPrice({currency, price: 0})
        row.querySelectorAll('[data-action]').forEach(action => {
            action.addEventListener(actionEventDictionary[action.tagName], productActionClickHandler)
        })
        productsWrapper.append(row)
    });
    wrapper.querySelector('#carrito-total').textContent = formatPrice({price: 0, currency})
}

const init = (catalog) => {
    carrito = new Carrito({catalog, formatPrice})
    initPaintProducts(catalog)
}

document.addEventListener('DOMContentLoaded', ()=> {
    fetch(`https://jsonblob.com/api/jsonBlob/${JSON_BLOB_ID}`)
    .then(res=>res.json())
    .then(init)
})
